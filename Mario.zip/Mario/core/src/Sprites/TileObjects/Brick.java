package Sprites.TileObjects;

import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.maps.MapObject;
import com.badlogic.gdx.math.Rectangle;
import com.mygdx.game.MarioBross;
import Scenes.Hud;
import com.mygdx.game.Screen.PlayScreen;
import Sprites.Mario;

/**
 * Created by brentaureli on 8/28/15.
 */
public class Brick extends InteractiveTileObject {
    public Brick(PlayScreen screen, MapObject object){
        super(screen, object);
        fixture.setUserData(this);
        setCategoryFilter(MarioBross.BRICK_BIT);
    }

    @Override
    public void onHeadHit(Mario mario) {
        if(mario.isBig()) {
            setCategoryFilter(MarioBross.DESTROYED_BIT);
            getCell().setTile(null);
            Hud.addScore(200);
            MarioBross.manager.get("audio/sounds/breakblock.wav", Sound.class).play();
        }
        MarioBross.manager.get("audio/sounds/bump.wav", Sound.class).play();
    }

}

